                                             ===================================================
                                             |                  WinUSB Maker                   |
                                             |                                                 |
                                             |        Developed by Josh Cell Softwares         |
                                             |                                                 |
                                             |              joshcellsoftwares.com              |
                                             ===================================================

                                           Here's the first BETA release of the WinUSB Maker v2.0


	New Features:
		
		Without any OS File-Mod - Your OS is clean transloaded to USB device.
		USB OS Transload compatible with Windows XP / Vista / Server / 7 / 8.
		Low memory and CPU usage for an fast OS Transload.
		Metro-UI Based compatible with Windows XP.
		Compatile with all Microsoft OS with .NET Framework v4.0.
		Backup and Restore is compatible only with the same device.
		MSDOS and GRLDR (Grub4DOS) compatible transload.
		Memory protections and code defuse improved.


	Transload Informations:

		With 5.x kernel (Windows XP / 2000 / 2003 / Server / PE and based);

			01 - Transload the OS to USB Device;
			02 - Boot the device and install the OS bootable copy into it (More info in the screen at the boot);
			03 - Your USB device is ready to any install.

		With 6.x kernel (Windows Vista / 7 / 8 / Server / PE and based);

			01 - Transload the OS to USB Device;
			02 - Your USB device is ready to any install.


		* OS based with the Windows boot kernel is also compatible. (As Norton Ghost and Recovery Systems).


	Release changes:

		- v2.0 BETA 1 [2012/05/23]

		Recoded and added the Windows XP full-support.
		New functions with the memory thread management.
		Redesigned the GUI controls.
		Metro-UI based.
		Stable controls.
		New ISO detection and Directory copy functions.
		Some more changes on the internal code.
		Improved the GUI Updates.

		- v2.0 BETA 2 [2012/06/04]

		Rewritten the GUI for a better english spelling (Thanks for ItielMaN @MDLForums)
		Solved the Kaspersky False-Positive problem
		Improved some functions
		New copy module added